function switchTab(to) {
    activetab = $('.tab-content .active').attr('id')
    $("#"+activetab).removeClass("active")
    $(to).addClass("active")
}